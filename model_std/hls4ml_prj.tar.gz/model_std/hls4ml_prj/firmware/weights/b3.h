//Numpy array shape [10]
//Min -0.559171080589
//Max 0.419650137424
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[10];
#else
model_default_t b3[10] = {-0.1852126122, 0.3132740259, 0.0062187589, -0.1560890675, 0.0653355569, 0.4196501374, -0.0495737679, 0.2689391971, -0.5591710806, -0.0895336419};
#endif

#endif
