//Numpy array shape [10]
//Min -0.539928555489
//Max 0.434126675129
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[10];
#else
model_default_t b3[10] = {-0.1935441047, 0.3180715740, 0.0027384004, -0.1598274112, 0.0839920491, 0.4341266751, -0.0392145738, 0.2340964079, -0.5399285555, -0.0888928622};
#endif

#endif
