//Numpy array shape [10]
//Min -0.543473422527
//Max 0.441394567490
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[10];
#else
model_default_t b3[10] = {-0.2096682191, 0.3244478703, 0.0217283424, -0.1752525717, 0.0674485043, 0.4413945675, -0.0512026697, 0.2678071856, -0.5434734225, -0.0914858282};
#endif

#endif
