//Numpy array shape [10]
//Min -0.573328375816
//Max 0.433961182833
//Number of zeros 0

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[10];
#else
model_default_t b3[10] = {-0.2130515724, 0.3314009905, 0.0093118967, -0.1644618511, 0.0799059570, 0.4339611828, -0.0658134297, 0.2451193035, -0.5733283758, -0.0720185265};
#endif

#endif
